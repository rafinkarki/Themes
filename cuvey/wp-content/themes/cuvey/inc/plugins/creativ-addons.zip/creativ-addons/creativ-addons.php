<?php

/*

Plugin Name: creativ Addons

Plugin URI: http://tuchuk.com/wordpress-free-plugins/creativ-addons

Description: This is addon for creativ theme to generate custom post types and widgets

Version: 1.0

Author: Sunil Chaulgain

Author URI: http://tuchuk.com

Text Domain: creativ-addons

*/

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) exit;



class creativAddons{

 

    public function __construct() {

 

        load_plugin_textdomain( 'creativ-addons', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' );

        add_filter( 'init', array( $this, 'creativ_addons_posttypes' ) );

        add_action( 'init', array( $this, 'custom_post_type' ) );

        add_action( 'init', array( $this, 'create_portfolio_taxonomies' ));

        add_filter( 'init', array( $this, 'creativ_addons_shortcode' ) );

 

    }



    public function creativ_addons_posttypes() {



    }



    public function creativ_addons_shortcode() {

      add_shortcode( 'portfolio', array($this, 'portfolio_shortcode') );

    }



    function portfolio_shortcode( $atts ) {
      $test=extract( shortcode_atts(
              array(
                 
                  'category' => '',
                  
                  'excerpt' => 'false',
              ), $atts )
      );  $output = '';
     
    return $output;
    }    

    public function custom_post_type() {

    $labels = array(
        'name'                => _x( 'Teams', 'Post Type General Name', 'creativ' ),
        'singular_name'       => _x( 'Team', 'Post Type Singular Name', 'creativ' ),
        'menu_name'           => __( 'Team', 'creativ' ),
        'parent_item_colon'   => __( 'Parent Team:', 'creativ' ),
        'all_items'           => __( 'All Teams', 'creativ' ),
        'view_item'           => __( 'View Team', 'creativ' ),
        'add_new_item'        => __( 'Add New Team', 'creativ' ),
        'add_new'             => __( 'Add New', 'creativ' ),
        'edit_item'           => __( 'Edit Team', 'creativ' ),
        'update_item'         => __( 'Update Team', 'creativ' ),
        'search_items'        => __( 'Search Team', 'creativ' ),
        'not_found'           => __( 'Not found', 'creativ' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'creativ' ),
    );
    $args = array(
        'label'               => __( 'team_member', 'creativ' ),
        'description'         => __( 'You can add the team members from here with their posts.', 'creativ' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor','thumbnail'),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 60,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'team', $args );

    $labels = array(
        'name'                => _x( 'Projects', 'Post Type General Name', 'creativ' ),
        'singular_name'       => _x( 'Project', 'Post Type Singular Name', 'creativ' ),
        'menu_name'           => __( 'Project', 'creativ' ),
        'parent_item_colon'   => __( 'Parent Project:', 'creativ' ),
        'all_items'           => __( 'All Projects', 'creativ' ),
        'view_item'           => __( 'View Project', 'creativ' ),
        'add_new_item'        => __( 'Add New Project', 'creativ' ),
        'add_new'             => __( 'Add New', 'creativ' ),
        'edit_item'           => __( 'Edit Project', 'creativ' ),
        'update_item'         => __( 'Update Project', 'creativ' ),
        'search_items'        => __( 'Search Project', 'creativ' ),
        'not_found'           => __( 'Not found', 'creativ' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'creativ' ),
    );
    $args = array(
        'label'               => __( 'portfolio_type', 'creativ' ),
        'description'         => __( 'You can create portfolios slider from here.', 'creativ' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor','thumbnail'),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 60,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'portfolio', $args );
    $labels = array(
        'name'                => _x( 'Events', 'Post Type General Name', 'creativ' ),
        'singular_name'       => _x( 'Events', 'Post Type Singular Name', 'creativ' ),
        'menu_name'           => __( 'Event', 'creativ' ),
        'parent_item_colon'   => __( 'Parent Event:', 'creativ' ),
        'all_items'           => __( 'All Events', 'creativ' ),
        'view_item'           => __( 'View Event', 'creativ' ),
        'add_new_item'        => __( 'Add New Event', 'creativ' ),
        'add_new'             => __( 'Add New', 'creativ' ),
        'edit_item'           => __( 'Edit Event', 'creativ' ),
        'update_item'         => __( 'Update Event', 'creativ' ),
        'search_items'        => __( 'Search Event', 'creativ' ),
        'not_found'           => __( 'Not found', 'creativ' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'creativ' ),
    );
    $args = array(
        'label'               => __( 'event_type', 'creativ' ),
        'description'         => __( 'You can create events and camps from here.', 'creativ' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor','thumbnail'),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 60,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'event', $args );

    $labels = array(
        'name'                => _x( 'Menu Items', 'Post Type General Name', 'creativ' ),
        'singular_name'       => _x( 'Menu Item', 'Post Type Singular Name', 'creativ' ),
        'menu_name'           => __( 'Menu Item', 'creativ' ),
        'parent_item_colon'   => __( 'Parent Menu Item:', 'creativ' ),
        'all_items'           => __( 'All Menu Items', 'creativ' ),
        'view_item'           => __( 'View Menu Item', 'creativ' ),
        'add_new_item'        => __( 'Add New Menu Item', 'creativ' ),
        'add_new'             => __( 'Add New', 'creativ' ),
        'edit_item'           => __( 'Edit Menu Item', 'creativ' ),
        'update_item'         => __( 'Update Menu Item', 'creativ' ),
        'search_items'        => __( 'Search Menu Item', 'creativ' ),
        'not_found'           => __( 'Not found', 'creativ' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'creativ' ),
    );
    $args = array(
        'label'               => __( 'menu_type', 'creativ' ),
        'description'         => __( 'You can create menus and camps from here.', 'creativ' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor','thumbnail'),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 60,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'menu', $args );

    }



    public function create_portfolio_taxonomies()

    {
    $labels = array(
        'name'                       => _x( 'Designations', 'Taxonomy General Name', 'creativ' ),
        'singular_name'              => _x( 'Designation', 'Taxonomy Singular Name', 'creativ' ),
        'menu_name'                  => __( 'Designation', 'creativ' ),
        'all_items'                  => __( 'All Items', 'creativ' ),
        'parent_item'                => __( 'Parent Item', 'creativ' ),
        'parent_item_colon'          => __( 'Parent Item:', 'creativ' ),
        'new_item_name'              => __( 'New Item Name', 'creativ' ),
        'add_new_item'               => __( 'Add New Item', 'creativ' ),
        'edit_item'                  => __( 'Edit Item', 'creativ' ),
        'update_item'                => __( 'Update Item', 'creativ' ),
        'separate_items_with_commas' => __( 'Separate items with commas', 'creativ' ),
        'search_items'               => __( 'Search Items', 'creativ' ),
        'add_or_remove_items'        => __( 'Add or remove items', 'creativ' ),
        'choose_from_most_used'      => __( 'Choose from the most used items', 'creativ' ),
        'not_found'                  => __( 'Not Found', 'creativ' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => false,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'team_post', array( 'team' ), $args );
       
    $labels = array(
        'name'                       => _x( 'Categories', 'Taxonomy General Name', 'creativ' ),
        'singular_name'              => _x( 'Filter', 'Taxonomy Singular Name', 'creativ' ),
        'menu_name'                  => __( 'Filter', 'creativ' ),
        'all_items'                  => __( 'All Items', 'creativ' ),
        'parent_item'                => __( 'Parent Item', 'creativ' ),
        'parent_item_colon'          => __( 'Parent Item:', 'creativ' ),
        'new_item_name'              => __( 'New Item Name', 'creativ' ),
        'add_new_item'               => __( 'Add New Item', 'creativ' ),
        'edit_item'                  => __( 'Edit Item', 'creativ' ),
        'update_item'                => __( 'Update Item', 'creativ' ),
        'separate_items_with_commas' => __( 'Separate items with commas', 'creativ' ),
        'search_items'               => __( 'Search Items', 'creativ' ),
        'add_or_remove_items'        => __( 'Add or remove items', 'creativ' ),
        'choose_from_most_used'      => __( 'Choose from the most used items', 'creativ' ),
        'not_found'                  => __( 'Not Found', 'creativ' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => false,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'portfolio_filter', array( 'portfolio' ), $args );
       
    $labels = array(
        'name'                       => _x( 'Types', 'Taxonomy General Name', 'creativ' ),
        'singular_name'              => _x( 'Type', 'Taxonomy Singular Name', 'creativ' ),
        'menu_name'                  => __( 'Type', 'creativ' ),
        'all_items'                  => __( 'All Items', 'creativ' ),
        'parent_item'                => __( 'Parent Item', 'creativ' ),
        'parent_item_colon'          => __( 'Parent Item:', 'creativ' ),
        'new_item_name'              => __( 'New Item Name', 'creativ' ),
        'add_new_item'               => __( 'Add New Item', 'creativ' ),
        'edit_item'                  => __( 'Edit Item', 'creativ' ),
        'update_item'                => __( 'Update Item', 'creativ' ),
        'separate_items_with_commas' => __( 'Separate items with commas', 'creativ' ),
        'search_items'               => __( 'Search Items', 'creativ' ),
        'add_or_remove_items'        => __( 'Add or remove items', 'creativ' ),
        'choose_from_most_used'      => __( 'Choose from the most used items', 'creativ' ),
        'not_found'                  => __( 'Not Found', 'creativ' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => false,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'event_type', array( 'event' ), $args );
     $labels = array(
        'name'                       => _x( 'Meals', 'Taxonomy General Name', 'creativ' ),
        'singular_name'              => _x( 'Meals', 'Taxonomy Singular Name', 'creativ' ),
        'menu_name'                  => __( 'Meals', 'creativ' ),
        'all_items'                  => __( 'All Items', 'creativ' ),
        'parent_item'                => __( 'Parent Item', 'creativ' ),
        'parent_item_colon'          => __( 'Parent Item:', 'creativ' ),
        'new_item_name'              => __( 'New Item Name', 'creativ' ),
        'add_new_item'               => __( 'Add New Item', 'creativ' ),
        'edit_item'                  => __( 'Edit Item', 'creativ' ),
        'update_item'                => __( 'Update Item', 'creativ' ),
        'separate_items_with_commas' => __( 'Separate items with commas', 'creativ' ),
        'search_items'               => __( 'Search Items', 'creativ' ),
        'add_or_remove_items'        => __( 'Add or remove items', 'creativ' ),
        'choose_from_most_used'      => __( 'Choose from the most used items', 'creativ' ),
        'not_found'                  => __( 'Not Found', 'creativ' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => false,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'menu_meal', array( 'menu' ), $args );

}
}
 
$addons = new creativAddons();