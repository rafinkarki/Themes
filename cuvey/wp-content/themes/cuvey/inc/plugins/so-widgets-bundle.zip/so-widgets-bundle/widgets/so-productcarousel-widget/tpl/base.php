<?php 
$query='post_type=product&posts_per_page='.esc_attr($instance['num']).'&meta_key=_featured&meta_value=yes';
$query = siteorigin_widget_post_selector_process_query( $query);
$loop = new WP_Query( $query );
?>
<?php
if ( $loop->have_posts() ) { 
	echo '<div id="shop-carousel" class="owl-carousel">';
	while ( $loop->have_posts() ) : $loop->the_post(); 
	echo '<div class="item">';?> 
	
   		<div class="carousel-shop">
	        <div class="shop-item">
				<?php wc_get_template_part( 'content', 'product' ); ?>
			</div>
		</div>
	<?php echo '</div>';?>	
	<?php endwhile;?>
	
	<?php echo '</div>';
} else {
	echo __( 'No products found' );
}
wp_reset_postdata();
?>
