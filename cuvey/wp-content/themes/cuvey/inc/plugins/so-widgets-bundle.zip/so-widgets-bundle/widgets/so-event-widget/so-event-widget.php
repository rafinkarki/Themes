<?php
/*
Widget Name: Event widget
Description: A simple event widget with date and image.
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/

class SiteOrigin_Widget_Event_Widget extends SiteOrigin_Widget {
	function __construct() {

		parent::__construct(
			'sow-event',
			__('Event(Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A customizable event widget with date and image.', 'siteorigin-widgets'),
			),
			array(

			),
			array(
				'number' => array(
					'type' => 'text',
					'label' => __('Number of Events to show', 'siteorigin-widgets'),
					'default'=>'3',
				),

				
			),			
		
			plugin_dir_path(__FILE__)
		);

	}
	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance) {
		return 'base';
	}

}

siteorigin_widget_register('event', __FILE__);