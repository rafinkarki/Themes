<?php $src = wp_get_attachment_image_src($instance['image'],$instance['size']); ?>
<?php if($instance['big-image']):
		$width='';
	else:
		$width='full';?>
<?php endif;?>
<div class=" image-container  clearfix">
	<div class="background-image-wrapper wow <?php echo esc_attr($instance['animation']);?>">
		<img class="background-image <?php echo $width;?> " alt="" src="<?php echo esc_url($src[0]);?>">
	</div>
	<?php if(!empty($instance['title'])):?>
		<div class="mini-title white-color">
	        <h2> <?php echo wp_kses_post( $instance['title'] ); ?></h2>
	    </div>
	<?php endif;?>
</div>
