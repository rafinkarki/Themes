<?php
/*
Widget Name:Image Slider widget
Description: A very simple image slider widget.
Author: Sunil Chaulagain	
Author URI: http://tuchuk.com
*/

class SiteOrigin_Widget_Image_Slider_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-image_slider',
			__('Image Slider(Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A simple image slider widget .', 'siteorigin-widgets'),
				
			),
			array(

			),
			array(
				'images' => array(
					'type' => 'repeater',
					'label' => __('Images', 'siteorigin-widgets'),
					'item_name' => __('Image', 'siteorigin-widgets'),
					'item_label' => array(
						'selector' => "[id*='images-alt']",
						'update_event' => 'change',
						'value_method' => 'val'
					),
					'fields' => array(
						'image' => array(
							'type' => 'media',
							'label' => __('Image file', 'siteorigin-widgets'),
						),
						'alt' => array(
							'type' => 'text',
							'label' => __('Image name', 'siteorigin-widgets'),
							'description' => __('This name will be displayed as alt value of a image.', 'siteorigin-widgets'),
						),
						
					),
				),
				
			),

			plugin_dir_path(__FILE__).'../'
		);
	}

	
	
	function get_template_name($instance) {
		return 'base';
	}

	function get_style_name($instance) {
		return false;
	}

	
}

siteorigin_widget_register('image_slider', __FILE__);