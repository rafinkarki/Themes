<?php $number=esc_attr($instance['number']);?>
<?php query_posts('post_type=team&post_status=publish&posts_per_page='.$number.'&paged='. get_query_var('paged')); ?>
<?php if($instance['layout']=='carousel'):
    $div='<div class="owl-team">';
    $main_start='<div id="team-members-carousel" class="row clearfix">';
    $main_end='</div>';
    $flag=1;
else:
    $div='<div class="col-md-4 col-sm-6 col-xs-12 nopadding owl-team">';
    $main_start='';
    $main_end='';
endif;?>
        <?php if (have_posts()) :  ?>
        <?php echo $main_start;?>            
            <?php while (have_posts()) : the_post();?>
              <?php  $pageid=get_the_ID();  
                $facebook=esc_attr(get_post_meta( $pageid, 'creativ_facebook',true));
                $twitter=esc_attr(get_post_meta( $pageid, 'creativ_twitter',true));
                $google=esc_attr(get_post_meta( $pageid, 'creativ_google',true));
                echo $div;?>
                    <div class="team-member wow fadeIn">
                        <div class="ImageWrapper">
                            <?php $thumbnail = get_post_thumbnail_id($post->ID);                        
                               $img_url = wp_get_attachment_image_src( $thumbnail,'full'); 
                               $n_img = aq_resize( $img_url[0], $width = 181, $height = 205.9, $crop = true, $single = true, $upscale = true ); ?>
                               <?php if($flag==0):?><img src="<?php echo esc_url($n_img);?>"  alt="">
                               <?php else:?><img src="<?php echo esc_url($img_url[0]);?>"  alt="">
                               <?php endif;?>
                            <div class="ImageOverlayLi"></div>
                            <div class="Buttons StyleH">
                                <div class="social-icons">
                                    <?php if (!empty($twitter)) : ?>
                                        <span><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom"  data-title="Twitter"  href="<?php echo esc_url( $twitter);?>" <?php echo  $instance['new_window'] ? 'target="_blank"' : '';  ?> ><i class="fa fa-twitter"></i></a></span>
                                    <?php endif;?>                       
                                    <?php if (!empty($facebook)) : ?>
                                        <span><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom"  data-title="Facebook" href="<?php echo esc_url( $facebook );?>" <?php echo  $instance['new_window'] ? 'target="_blank"' : '';  ?> ><i class="fa fa-facebook"></i></a></span>
                                    <?php endif;?>
                                    <?php if (!empty($google)) : ?>
                                        <span><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom"  data-title="Google Plus" href="<?php echo esc_url( $google );?>" <?php echo  $instance['new_window'] ? 'target="_blank"' : '';  ?>> <i class="fa fa-google-plus"></i></a></span>
                                    <?php endif;?>
                                </div><!-- end social icons -->
                            </div>
                        </div>
                        <?php if($flag==1){?>
                            <div class="team_desc">
                                <h3><?php creativ_post_title(); ?></h3>
                                <?php
                                $filters = get_the_terms($post->ID,'team_post');
                                $c_filter = '';
                                if(!empty($filters)){
                                    foreach($filters as $f=>$filter){
                                        $c_filter .=  ($f==0) ? $filter->name : ', '.$filter->name;
                                    }
                                    echo "<p>".esc_html($c_filter)."</p>";
                                }
                                ?>  
                            </div><!-- end team_Desc -->
                        <?php }?>
                    </div><!-- end ImageWrapper -->
               
                </div>
            <?php endwhile; ?>              
        <?php echo $main_end;?>   
            <?php else : ?>

                <?php get_template_part('partials/nothing-found'); ?>

        <?php endif; wp_reset_query();?>
   