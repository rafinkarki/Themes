<?php foreach( $instance['progressbar'] as $progressbar ) : $rand=rand();?>
	<style>
		.progress-bar-<?php echo $rand;?>{
			background:<?php echo esc_html($progressbar['color']);?>;
		}
	</style>	  
	<div class="progress <?php echo $progressbar['strip']?'progress-striped active':'';?>">
	    <div class="progress-bar wow slideInLeft progress-bar-<?php echo $rand;?>" role="progressbar" aria-valuenow="<?php  echo esc_html($progressbar['percent']);?>" aria-valuemin="0" aria-valuemax="100"  style="width:<?php echo esc_html($progressbar['percent']);?><?php _e('%','siteorigin_widgets')?>;">
	        <span class="sr-only"><?php echo esc_html($progressbar['percent']);?><?php _e('% Complete','siteorigin_widgets')?></span>
	    </div>
	    <span class="progress-type"><?php echo esc_attr($progressbar['title']); ?></span>
	    <span class="progress-completed"><?php echo esc_html($progressbar['percent']);?><?php _e('%','siteorigin_widgets')?></span>
	</div>

<?php endforeach;?>    