<div class="full-image-section">
<div id="first-slider" class="carousel-right-side">
    <?php foreach($instance['informations'] as $i => $information) : ?>      
        <div class="owl-item">
            <div class="section-content text-wrapper  col-sm-offset-0 clearfix">
                <div class="section-title text-left">
                    <h3><?php echo esc_attr( $information['title'] ); ?></h3>
                    <p><?php echo nl2br(wp_kses_post( $information['text']) ) ;?></p>
                    <?php if( $information['btnurl']!='') : ?>
                        <a href="<?php echo esc_url( $information['btnurl'] ); ?>" <?php ( $instance['new_window'] ? 'target="_blank"' : '' ) ; ?> class="btn btn-primary btn-lg border-radius"><?php echo wp_kses_post( $information['btntext'] ); ?></a>
                    <?php endif; ?>
                </div><!-- end section title -->
            </div><!-- end col -->
        </div><!-- end owl-item -->
    <?php endforeach;?>
</div>
</div>