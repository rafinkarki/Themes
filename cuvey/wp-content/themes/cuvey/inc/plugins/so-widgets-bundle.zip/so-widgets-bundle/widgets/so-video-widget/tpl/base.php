<div id="video-parallax">
 <div class="section-title">
    <a href="<?php echo esc_url($instance['video']);?>" rel="prettyPhoto" title=""><i class="fa fa-play border-radius"></i></a>
    <?php if(!empty($instance['title']))  : ?>
	    <h3><?php echo nl2br(wp_kses_post( $instance['title'] )); ?></h3>
	<?php endif; ?>    
</div><!-- end section title -->
</div>
