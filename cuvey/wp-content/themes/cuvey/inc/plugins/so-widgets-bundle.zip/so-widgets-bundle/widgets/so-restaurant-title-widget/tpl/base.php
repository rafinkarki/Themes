<div class="restaurant-title">
<div class="section-title">
    <h<?php  echo esc_attr($instance['size']);?>><?php echo wp_kses_post( $instance['title'] ); ?></h<?php  echo $instance['size'];?>>
</div>
</div>
