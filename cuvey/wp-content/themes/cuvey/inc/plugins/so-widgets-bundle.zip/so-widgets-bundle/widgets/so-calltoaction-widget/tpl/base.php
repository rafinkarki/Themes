<div class="welcome-message row">

    <div class="col-md-10">

    	<?php $src=wp_get_attachment_image_src($instance['image'],'full');?>    	

        <h3><img src="<?php echo esc_url($src[0]);?>" alt=""><?php echo wp_kses_post( $instance['text'] ); ?></h3>

    </div><!-- end col -->

    <div class="col-md-2">

    	<?php if( $instance['btnurl']!='') : ?>

        <a href="<?php echo esc_url( $instance['btnurl'] ); ?>" <?php echo ( $instance['new_window'] ? 'target="_blank"' : '' ) ; ?> class="btn btn-primary <?php echo (!empty($instance['round'])?'border-radius':'');?>"><?php echo wp_kses_post( $instance['btntext'] ); ?></a>

        <?php endif; ?>

    </div><!-- end col -->

</div>

