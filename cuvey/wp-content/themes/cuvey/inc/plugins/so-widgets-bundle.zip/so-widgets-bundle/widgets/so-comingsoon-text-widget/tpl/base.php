<?php if(!empty( $instance['title'])): $rand=rand(); $style='';
if($instance['italic']) $style='font-style:italic';?>
	<div class="coming-soon-wrapper<?php echo $rand;?> clearfix">           
		<p><?php echo nl2br(wp_kses_post( $instance['title'] )); ?></p>
	</div>
	<style>
		.coming-soon-wrapper<?php echo $rand;?> p{
		  font-family: Athelas;
		  color: <?php echo esc_html($instance['color']);?>;
		  font-size: 24px;
		  <?php echo $style;?>;
		  text-align:<?php echo esc_html($instance['align']);?>
		}
	</style>
<?php endif;?>