<?php
/*
widget Name: Call to action widget
Description: A powerful yet simple calltoaction widget for your sidebars or Page Builder pages.
Author: Sunil Chaulagain	
Author URI: http://tuchuk.com
*/

class SiteOrigin_Widget_Calltoaction_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-calltoaction',
			__('Call to Action (Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A call to action widget.', 'siteorigin-widgets'),
				
			),
			array(

			),
			array(		
					
				'text' => array(
					'type' => 'text',
					'label' => __('Main text', 'siteorigin-widgets'),
				),

				'image' => array(
					'type' => 'media',
					'label' => __('Image', 'siteorigin-widgets'),
				),

				'btntext' => array(
					'type' => 'text',
					'label' => __('Button text', 'siteorigin-widgets'),
				),

				'btnurl' => array(
					'type' => 'text',
					'sanitize' => 'url',
					'label' => __('Destination URL', 'siteorigin-widgets'),
				),

				'new_window' => array(
					'type' => 'checkbox',
					'default' => false,
					'label' => __('Open in a new window', 'siteorigin-widgets'),
				),

				'round' => array(
					'type' => 'checkbox',
					'default' => true,
					'label' => __('Use round button', 'siteorigin-widgets'),
				),

			),
			plugin_dir_path(__FILE__).'../'
		);
	}


	function get_template_name($instance) {
		return 'base';
	}

	function get_style_name($instance) {
		return false;
	}

	
}

siteorigin_widget_register('calltoaction', __FILE__);