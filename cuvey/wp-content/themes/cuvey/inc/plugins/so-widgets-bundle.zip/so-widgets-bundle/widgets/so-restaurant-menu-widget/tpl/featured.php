<?php $number=esc_attr($instance['number']);$left="pull-left";$right="pull-right";
$arg = array(
    'post_type' => 'menu',
    'posts_per_page'=>$number,
    'meta_query' => array(
        array(
            'key' => 'creativ_featured',
            'value' => 'yes',
        )
    )
 ); $query = new WP_Query( $arg );   
?> 
<?php if ($query->have_posts()) : $i=0;?>
    <div class="vegs">
    <?php while ($query->have_posts()) : $query->the_post(); ?>
        <div class="<?php if($i%2==0): echo $left; else: echo $right; endif;?> col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="menu-res">
                <div class="item clearfix">
                    <div class="ImageWrapper pull-left border-radius red-effect">
                        <?php $thumbnail = get_post_thumbnail_id($post->ID);                        
                           $img_url = wp_get_attachment_image_src( $thumbnail,'full'); //get img URL
                           //$n_img = aq_resize( $img_url[0], $width = 263, $height = 198, $crop = true, $single = true, $upscale = true );
                        ?>
                        <img class="img-responsive img-circle" src="<?php echo esc_url($img_url[0]);?>" alt="">
                        <div class="ImageOverlayLi"></div>
                        <!-- <div class="Buttons StyleH">
                            <span><a href="shop.html">Order Now</a></span>
                        </div> -->
                    </div>

                    <div class="res-title">
                        <h3><?php creativ_post_title(); ?></h3>
                    </div><!-- end title -->                     

                    <div class="desc">
                        <p>
                            <?php 
                                //$postContentStr = apply_filters('the_content', strip_shortcodes($post->post_content));
                                echo wp_kses_post(the_content());  
                            ?>
                        </p>
                    </div><!-- end desc -->
                    <?php $price =esc_attr(get_post_meta(get_the_ID(), 'creativ_price', true ));?>
                    <?php if(!empty($price)):?>
                        <div class="price">
                            <div class="pull-left">
                                <h4><?php echo $price;?></h4>
                            </div><!-- end left -->
                        </div><!-- end price -->
                    <?php endif;?>
                </div><!-- end item -->
            </div>
        </div>   
        <?php ++$i;?> 
    <?php endwhile;?>
    </div><!--vegs-->
<?php else : ?>
    <?php get_template_part('partials/nothing-found'); ?>
<?php endif; wp_reset_query();?>
  