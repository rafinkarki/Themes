<?php
/*
Widget Name: Coming Soon Text widget
Description: Displays Text for coming soon page
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/
class SiteOrigin_Widget_ComingSoonText_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-comingsoontext',
			__('Coming Soon Text(Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A simple text widget for coming soon page.', 'siteorigin-widgets'),
				
			),
			array(
				),
			array(

				'title' => array(
					'type' => 'textarea',
					'label' => __('Text Text', 'siteorigin-widgets'),
				),
				'color' => array(
					'type' => 'color',
					'label' => __('Text Color', 'siteorigin-widgets'),
					'default'=>'#fff',
				),	

				'align' => array(
					'type' => 'select',
					'label' => __('Alignment', 'siteorigin-widgets'),
					'options' => array(
						'left' => __('Left', 'siteorigin-widgets'),
						'right' => __('Right', 'siteorigin-widgets'),
						'center' => __('Center', 'siteorigin-widgets'),
					)
				),
				'italic' => array(
					'type' => 'checkbox',
					'label' => __('Italic text?', 'siteorigin-widgets'),
				),
			)
		);
	}


	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		return 'base';
	}
}
siteorigin_widget_register('comingsoontext', __FILE__);