<div class="title-wrapper text-<?php echo wp_kses_post( $instance['align'] ); ?>">
	<?php if(!empty( $instance['title'])):?>
	    <div class="<?php echo ($instance['style']?'section-title-freelance':'section-title-2');?>" >
	        <h<?php  echo esc_attr($instance['size']);?> class="h_class" 
	        	<?php if($instance['style']): 
	        		echo  'style="color:'.esc_html($instance['t_color']).'; background:none repeat scroll 0 0 '.esc_html($instance['b_color']).';"'; 
	        	else: 
	        		echo 'style="color:'.esc_html($instance['t_color']).';"'; 
	        	endif;?>>
	        	<?php echo nl2br(wp_kses_post( $instance['title']) ); ?>
	        </h<?php  echo esc_attr($instance['size']);?>>
	    </div>
	<?php endif;?>
	    <?php if(!empty($instance['subtitle']))  : ?>
	    	<p><?php echo nl2br(wp_kses_post( $instance['subtitle'] )); ?></p>
		<?php endif; ?>
		
</div>
