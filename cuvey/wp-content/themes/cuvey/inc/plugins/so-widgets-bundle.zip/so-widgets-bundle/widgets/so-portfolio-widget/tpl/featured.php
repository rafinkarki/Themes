<?php $number=esc_attr($instance['number']);

$arg = array(
    'post_type' => 'portfolio',
    'posts_per_page'=>$number,
    'meta_query' => array(
        array(
            'key' => 'creativ_featured_project',
            'value' => 'yes',
        )
    )
 );
$query = new WP_Query( $arg );?>
        <?php if ($query->have_posts()) : ?>
            <div id="home-portfolio" class="row-fluid clearfix">      
                <?php while ($query->have_posts()) : $query->the_post(); ?>
                <?php
                $portfolio_item_title = get_the_title( $post->ID );
                $image_url= wp_get_attachment_thumb_url( get_post_thumbnail_id($post->ID) );
                $thumb =  wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                $terms = get_the_terms( $post->ID, 'portfolio_filter' );          
                if ( $terms && ! is_wp_error( $terms ) ) : 

                    $term_links = array();
                    foreach ( $terms as $term ) {
                        $term_links[] = $term->slug;
                    }
                                        
                    $filters = join( " ", $term_links );
                endif;   
                ?>
                
             
                
                <div class="col-md-3 col-sm-6 col-xs-12 portfolio-item wow fadeIn">
                    <div class="ImageWrapper">
                        <?php $thumbnail = get_post_thumbnail_id($post->ID);                        
                           $img_url = wp_get_attachment_image_src( $thumbnail,'full'); //get img URL
                           $n_img = aq_resize( $img_url[0], $width = 338, $height = 396, $crop = true, $single = true, $upscale = true );
                        ?><img src="<?php echo esc_url($n_img);?>" alt="" class="img-responsive"> 
                        <div class="ImageOverlayLi"></div>
                        <div class="Buttons StyleH">                                                                
                            <?php
                                $filters = get_the_terms($post->ID,'portfolio_filter');
                                $c_filter = '';
                                if(!empty($filters)){
                                    foreach($filters as $f=>$filter){
                                        $c_filter .=  ($f==0) ? $filter->name : ', '.$filter->name;
                                    }
                                    echo "<p>".esc_html($c_filter)."</p>";
                                }
                            ?><span class="divider-hover"></span>                                    
                            <h3><a href="<?php echo the_permalink();?>" title=""><?php creativ_post_title(); ?></a></h3>
                            <a href="<?php echo the_permalink();?>" title=""title="" class="btn btn-primary border-radius"><?php _e('See Project','siteorigin_widgets');?></a>
                           
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>              
            </div>
        <?php else : ?>

            <?php get_template_part('partials/nothing-found'); ?>

        <?php endif; wp_reset_postdata();?>