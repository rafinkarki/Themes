<?php
/*
Widget Name: Icons widget
Description: Displays a block of icons and name in grid view.
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/

class SiteOrigin_Widget_Icons_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-icons',
			__( 'Icons(Builder)', 'siteorigin-widgets' ),
			array(
				'description' => __( 'Displays a list of icons with name in grid view.', 'siteorigin-widgets' ),
				
			),
			array(),
			array('icons' => array(
					'type' => 'repeater',
					'label' => __('Icons', 'siteorigin-widgets'),
					'item_name' => __('Icon', 'siteorigin-widgets'),
					'item_label' => array(
						'selector' => "[id*='icons-title']",
						'update_event' => 'change',
						'value_method' => 'val'
					),
					'fields' => array(			
				
						'icon' => array(
							'type' => 'icon',
							'label' => __('Icon', 'siteorigin-widgets'),
						),
				
						'title' => array(
							'type' => 'text',
							'label' => __('Text', 'siteorigin-widgets'),
						),

						'bg_color' => array(
							'type' => 'color',
							'label' => __('Background Grid Color', 'siteorigin-widgets'),
						
						),
					),
				),
			),
			plugin_dir_path(__FILE__).'../'
		);
	}


	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		return 'base';
	}

	
}

siteorigin_widget_register('icons', __FILE__);