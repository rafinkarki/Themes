<?php
/*
Widget Name: Restaurant Title widget
Description: Displays Title
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/
class SiteOrigin_Widget_RestaurantTitle_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-restauranttitle',
			__('Restaurant Title (Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A simple title widget.', 'siteorigin-widgets'),
				
			),
			array(
				),
			array(

				'title' => array(
					'type' => 'text',
					'label' => __('Title Text', 'siteorigin-widgets'),
				),
				'color' => array(
					'type' => 'color',
					'label' => __('Title Color', 'siteorigin-widgets'),
					'default'=>'#000',
				),
							

				'size' => array(
					'type' => 'select',
					'label' => __('Title Size', 'siteorigin-widgets'),
					'options' => array(
						'1' => __('H1', 'siteorigin-widgets'),
						'2' => __('H2', 'siteorigin-widgets'),
						'3' => __('H3', 'siteorigin-widgets'),
						'4' => __('H4', 'siteorigin-widgets'),
						'5' => __('H5', 'siteorigin-widgets'),
						'6' => __('H6', 'siteorigin-widgets'),
						
					)
				),

				'align' => array(
					'type' => 'select',
					'label' => __('Alignment', 'siteorigin-widgets'),
					'options' => array(
						'left' => __('Left', 'siteorigin-widgets'),
						'right' => __('Right', 'siteorigin-widgets'),
						'center' => __('Center', 'siteorigin-widgets'),
					)
				),
			)
		);
	}


	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		return 'base';
	}
}
siteorigin_widget_register('restauranttitle', __FILE__);