<?php if(!empty( $instance['title'])):?>
	<div class="title-wrapper clearfix">
	    <div class="shop-title">
	        <div class="title-text-inner">
	            <h<?php  echo esc_attr($instance['size']);?>><?php echo wp_kses_post( $instance['title'] ); ?></h<?php  echo esc_attr($instance['size']);?>>
	        </div>
	    </div>
	</div><!-- end title --> 
<?php endif;?>