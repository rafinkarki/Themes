<?php
/*
Widget Name: Text Slider widget
Description: Displays slider with text and button.
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/

class SiteOrigin_Widget_TextSlider_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-textslider',
			__( 'Text Slider(Builder)', 'siteorigin-widgets' ),
			array(
				'description' => __( 'Displays simple slider with text and button', 'siteorigin-widgets' ),
				
			),
			array(),
			array(
					
				'slider' => array(
					'type' => 'repeater',
					'label' => __('Contents', 'siteorigin-widgets'),
					'item_name' => __('Content', 'siteorigin-widgets'),
					'item_label' => array(
						'selector' => "[id*='slider-title']",
						'update_event' => 'change',
						'value_method' => 'val'
					),
					'fields' => array(
						'title' => array(
							'type' => 'text',
							'label' => __('Name', 'siteorigin-widgets'),
						),
						't_color' => array(
							'type' => 'color',
							'label' => __('Title Color', 'siteorigin-widgets'),
							'default'=>'#fff',
						),
						'b_color' => array(
							'type' => 'color',
							'label' => __('Title Background Color', 'siteorigin-widgets'),
							'default'=>'#282828',
						),
						
						'text' => array(
							'type' => 'textarea',
							'label' => __('Description', 'siteorigin-widgets'),
							'description' => __( 'Use span tag if needed.', 'siteorigin-widgets' )
						),
					
					),
				),
			),
			plugin_dir_path(__FILE__).'../'
		);
	}

	

	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		return 'base';
	}

	
}

siteorigin_widget_register('textslider', __FILE__);