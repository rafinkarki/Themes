<?php $number=esc_attr($instance['number']);$class='label-green';?>

<?php query_posts('post_type=event&post_status=publish&posts_per_page='.$number.'&paged='. get_query_var('paged')); ?>
              
        <?php 
        $arguments = array(
        'type'                     => 'event',
        'taxonomy'                 => 'event_type',
        'pad_counts'               => false 
        );         
        $categories = get_categories( $arguments );
        ?>        
       
        <?php if (have_posts()) : ?>
             <?php while (have_posts()) : the_post(); ?>
             <?php $featured =esc_attr(get_post_meta(get_the_ID(), 'creativ_event', true ));
                  $event_sdate =esc_attr(get_post_meta(get_the_ID(), 'creativ_s_date', true ));
                  $event_edate =esc_attr(get_post_meta(get_the_ID(), 'creativ_e_date', true ));
                  $s_date = strtotime( $event_sdate );
                  $e_date = strtotime( $event_edate );
                  if($featured=='yes'): $class='label-red'; else: $class='label-green';endif;
            ?>
            <div class="custom-services">
                <div class="custom-service-box">
                    <div class="ImageWrapper pull-left border-radius red-effect">
                         <?php $thumbnail = get_post_thumbnail_id($post->ID);                        
                           $img_url = wp_get_attachment_image_src( $thumbnail,'full'); //get img URL
                           //$n_img = aq_resize( $img_url[0], $width = 263, $height = 198, $crop = true, $single = true, $upscale = true );
                        ?>
                        <img class="img-responsive img-circle" src="<?php echo esc_url($img_url[0]);?>" alt="">
                        <div class="ImageOverlayLi"></div>
                        <!-- <div class="Buttons StyleH">
                            <span><a href="shop.html"><i class="fa fa-link border-radius"></i></a></span>
                        </div> -->
                    </div>
                    <div class="res-title">
                        <h3><?php creativ_post_title(); ?></h3>
                    </div><!-- end title -->
                     
                    <div class="meta">
                        <?php
                        $filters = get_the_terms($post->ID,'event_type');
                        $c_filter = '';
                        if(!empty($filters)){
                            foreach($filters as $f=>$filter){
                                $c_filter .=  ($f==0) ? $filter->name : ', '.$filter->name;
                            }
                            echo '<span class="label '.$class.'">'.esc_html($c_filter).'</span>';
                        }
                        ?>  
                        <span><i class="fa fa-calendar"></i><?php echo date( 'j M Y', $s_date ); ?><?php _e(' - ','siteorigin_widgets');?><?php echo date( 'j M Y', $e_date ); ?></span>
                    </div>
                    <div class="desc">
                        <?php 
                                //$postContentStr = apply_filters('the_content', strip_shortcodes($post->post_content));
                                echo wp_kses_post(the_content());  
                            ?>
                    
                    </div><!-- end desc -->
                </div><!-- end box -->
            </div><!-- end customservices -->
           <?php endwhile;?>
        <?php else : ?>

            <?php get_template_part('partials/nothing-found'); ?>

        <?php endif; wp_reset_query();?>
        
  