<?php $c_array=array(0=>'#FFCC0E',1=>'#18E2BA',2=>'#564BB5',3=>'#E85D5D',4=>'#69A136',5=>'#CE7E28',6=>'#03ACDC',7=>'#FFCC0E',8=>'#18E2BA',9=>'#564BB5',10=>'#03ACDC');
$count=0;$number=esc_attr($instance['number']);?>
<?php query_posts('post_type=team&post_status=publish&posts_per_page='.$number.'&paged='. get_query_var('paged')); ?>
<?php if($instance['layout']=='alt-isotope'):   
    $flag=1;
    $id='-2';
else:
    $flag=0;
    $id='';
endif;?>
    <div id="second" class="container bf">                
        <?php 
        $arguments = array(
        'type'                     => 'team',
        'taxonomy'                 => 'team_post',
        'pad_counts'               => false 
        );         
        $categories = get_categories( $arguments );
        ?>     
        <ul class="filter">        
            <li><a class="blue-color-team" data-cat="all" href="#" class="active"><?php _e( 'All', 'creativ' ); ?></a></li>
            <?php foreach($categories as $i=>$category) { ?>
            <li><a class="yellow-color" style="background:<?php echo esc_html($c_array[$count]).' !important';?>;" data-cat="<?php echo $category->slug; ?>" href="#"><?php echo $category->name; ?></a></li>
            <?php ++$count; 
            if($count>10) $count=0;
            } ?>
        </ul>
        <?php $count=0;?>
            <?php if (have_posts()) :  ?>                       
                <ul id="team-portfolio<?php echo $id;?>" class="items row-fluid">
                <?php while (have_posts()) : the_post(); $rand=rand();?>
                <?php $pageid=get_the_ID();  
                $facebook=esc_attr(get_post_meta( $pageid, 'creativ_facebook',true));
                $twitter=esc_attr(get_post_meta( $pageid, 'creativ_twitter',true));
                $google=esc_attr(get_post_meta( $pageid, 'creativ_google',true));
                $terms = get_the_terms( $pageid, 'team_post' );
                $team_item_title = get_the_title( $pageid);
                $image_url= wp_get_attachment_thumb_url( get_post_thumbnail_id($post->ID) );
                $thumb =  wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                $terms = get_the_terms( $post->ID, 'team_post' );        
                if ( $terms && ! is_wp_error( $terms ) ) :
                    $term_links = array();
                    foreach ( $terms as $term ) {
                        $term_links[] = $term->slug;
                    }                                        
                    $filters = join( " ", $term_links );
                endif; ?>
                <li class="<?php echo $filters; ?>">
                    <div class="bf-single-item wow fadeIn">
                        <?php $thumbnail = get_post_thumbnail_id($post->ID);                        
                           $img_url = wp_get_attachment_image_src( $thumbnail,'full'); //get img URL
                           $n_img = aq_resize( $img_url[0], $width = 285, $height = 285, $crop = true, $single = true, $upscale = true ); 
                        ?><img src="<?php echo esc_url($n_img);?>" alt=""> 
                        <?php $hex_color = str_replace("#", "", esc_attr($c_array[$count]));

                           if(strlen($hex_color) == 3) {
                              $r = hexdec(substr($hex_color,0,1).substr($hex_color,0,1));
                              $g = hexdec(substr($hex_color,1,1).substr($hex_color,1,1));
                              $b = hexdec(substr($hex_color,2,1).substr($hex_color,2,1));
                           } else {
                              $r = hexdec(substr($hex_color,0,2));
                              $g = hexdec(substr($hex_color,2,2));
                              $b = hexdec(substr($hex_color,4,2));
                           }
                            $color= array($r, $g, $b); ?>
                        <div class="caption purple-bg<?php echo $rand;?>" >
                            <div class="cap-in">
                                <?php if (!empty($twitter)) : ?>
                                    <a class="icon<?php echo $rand;?>"  href="<?php echo esc_url( $twitter);?>" <?php echo  $instance['new_window'] ? 'target="_blank"' : '';  ?> title=""><span class="bubble border-radius"><i class="fa fa-twitter"></i></span></a>
                                <?php endif;?>                       
                                <?php if (!empty($facebook)) : ?>
                                    <a class="icon<?php echo $rand;?>" href="<?php echo esc_url( $facebook );?>" <?php echo  $instance['new_window'] ? 'target="_blank"' : '';  ?> title=""><span class="bubble border-radius"><i class="fa fa-facebook"></i></span></a>
                                <?php endif;?>
                                <?php if (!empty($google)) : ?>
                                    <a  class="icon<?php echo $rand;?>" href="<?php echo esc_url( $google );?>" <?php echo  $instance['new_window'] ? 'target="_blank"' : '';  ?> title=""><span class="bubble border-radius"><i class="fa fa-google-plus"></i></span></a>
                                <?php endif;?> 
                                <?php if($flag==0):?>                                 
                                    <div class="caps-desc">
                                        <h3><a href="<?php echo the_permalink();?>" title=""><?php creativ_post_title(); ?></a></h3>
                                        <?php
                                        $filters = get_the_terms($post->ID,'team_post');
                                        $c_filter = '';
                                        if(!empty($filters)){
                                            foreach($filters as $f=>$filter){
                                                $c_filter .=  ($f==0) ? $filter->name : ', '.$filter->name;
                                            }
                                            echo "<p>".esc_html($c_filter)."</p>";
                                        }
                                        ?>  
                                    </div><!-- end caps --> 
                                <?php endif;?>                               
                             </div>
                        </div>
                        <?php if($flag==1):?>                                 
                            <div class="caps-desc">
                                <h3><a href="<?php echo the_permalink();?>" title=""><?php creativ_post_title(); ?></a></h3>
                                <?php
                                $filters = get_the_terms($post->ID,'team_post');
                                $c_filter = '';
                                if(!empty($filters)){
                                    foreach($filters as $f=>$filter){
                                        $c_filter .=  ($f==0) ? $filter->name : ', '.$filter->name;
                                    }
                                    echo "<p>".esc_html($c_filter)."</p>";
                                }
                                ?>  
                            </div><!-- end caps --> 
                        <?php endif;?>  
                    </div>
                </li>
                <style >
                .bf ul.items.bflayhover li .caption.purple-bg<?php echo $rand;?>{
                    background: rgba(<?php echo $color['0'].','.$color['1'].','.$color['2'].',0.7';?>) !important;
                    }
                .purple-bg<?php echo $rand;?> a.icon<?php echo $rand;?> .bubble i{
                    color: rgba(<?php echo $color['0'].','.$color['1'].','.$color['2'].',1';?>) !important;
                    }
                .purple-bg<?php echo $rand;?> .bubble {
                  background: #fff !important;
                }
                </style>
                <?php  ++$count; 
                if($count>10) $count=0;
            endwhile; ?>              
            </ul>
            <?php else : ?>

                <?php get_template_part('partials/nothing-found'); ?>

            <?php endif; wp_reset_query();?>
        
    </div>  
   