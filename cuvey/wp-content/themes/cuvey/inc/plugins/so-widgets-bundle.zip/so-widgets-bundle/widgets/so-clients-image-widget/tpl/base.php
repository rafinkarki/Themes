<?php if( $instance['url']!='') : ?>
    <a href="<?php echo esc_url( $instance['url'] ); ?>" <?php echo ( $instance['new_window'] ? 'target="_blank"' : '' ) ; ?>>
        <?php $src = wp_get_attachment_image_src($instance['image'], 'full');?>
        <img src="<?php echo esc_url($src[0]);?>" alt="" class="img-responsive">
    </a>
<?php endif; ?>