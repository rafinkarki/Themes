<?php
/*
Widget Name: Portfolio widget
Description: A simple portfolio widget to display project with multiple variation in layout.
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/

class SiteOrigin_Widget_Portfolio_Widget extends SiteOrigin_Widget {
	function __construct() {

		parent::__construct(
			'sow-portfolio',
			__('Portfolio(Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A customizable portfolio widget with multiple variations.', 'siteorigin-widgets'),
			),
			array(

			),
			array(
				'number' => array(
					'type' => 'text',
					'label' => __('Number of Portfolio Projects', 'siteorigin-widgets'),
					'default'=>'5',
				),

				'layout' => array(
					'type' => 'select',
					'label' => __('Portfolio theme', 'siteorigin-widgets'),
					'default' => 'atom',
					'options' => array(
						'featured'   =>'Featured Portfolio',                              
                        '2'   =>'Two Columns',                                                              
                        '3'   =>'Three Columns',                                
                        '4'   =>'Four Columns', 
                        '2t'  =>'Two Columns Text',                               
                        '3t'  =>'Three Columns Text',
                        '4t'  =>'Four Columns Text',                             
                        'gf3' =>'Gallery Three Columns',
                        'gf4' =>'Gallery Four Columns',
                        'gf5' =>'Gallery Five Columns',
                        'gg2' =>'Gird Two Columns',
                        'gg3' =>'Grid Three Columns',
                        'gg4' =>'Grid Four Columns',
                        'm2'  =>'Masonry Two Columns',
                        'm3'  =>'Masonry Three Columns',
                        'm4'  =>'Masonry Four Columns',
                        'mm' =>'Masonry Mixed Columns Type 1', 
                        'mm2' =>'Masonry Mixed Columns Type 2',                         
                        'mm1' =>'Masonry Photography Style',               
					),
					
				),
				'checkbox' => array(
					'type' => 'checkbox',
					'label' => __('Hide project filter items', 'siteorigin-widgets'),
				),
			),			
		
			plugin_dir_path(__FILE__)
		);

	}
	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance) {
		if($instance['layout']=='m2' || $instance['layout']=='m3' || $instance['layout']=='m4')
			return 'masonry';
		elseif($instance['layout']=='gg2' || $instance['layout']=='gg3' || $instance['layout']=='gg4')
			return 'grid';
		elseif($instance['layout']=='gf5' || $instance['layout']=='gf3' || $instance['layout']=='gf4')
			return 'gallery';
		elseif($instance['layout']=='2t' || $instance['layout']=='3t' || $instance['layout']=='4t')
			return 'classic-text';
		elseif($instance['layout']=='2' || $instance['layout']=='3' || $instance['layout']=='4')
			return 'classic';
		else
		return $instance['layout'];
	}

}

siteorigin_widget_register('portfolio', __FILE__);