<div id="freelancer-style" class="owl-carousel">
	<?php foreach( $instance['slider'] as $i => $slider ) : ?>
	    <div class="item">
	        <div class="about-tabbed-wrap">
	            <div class="title-wrapper">
	            <?php if(!empty( $slider['title'])):?>
	                <div class="mini-2-title">
	                    <h3 class="text-slider" style="color:<?php echo esc_html($slider['t_color']);?>!important; background:<?php echo esc_html($slider['b_color']);?>!important;"><?php echo esc_attr($slider['title']);?></h3>
	                </div>
	            <?php endif;?>
	            </div><!-- end title -->	        
	            <p><?php echo nl2br(wp_kses_post($slider['text']));?></p>
	        </div>
	    </div><!-- end item -->
	<?php endforeach;?>
</div>