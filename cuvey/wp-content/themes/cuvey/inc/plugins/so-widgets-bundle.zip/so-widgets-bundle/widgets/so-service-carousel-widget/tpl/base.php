<?php if($instance['style']=='little'):
	$container='border-radius-little';
else:
	$container='border-radius';
endif;?>

<div id="owl-services" class="clearfix">
	<?php foreach( $instance['services'] as $i => $service ) : ?>
	    <div class="owl-item">
	        <div class="service_vertical_box">
	            <div class="wow <?php echo esc_attr($instance['icon_animation']);?> service-icon color-blue <?php echo $container;?>" style="background:<?php echo esc_html($service['color']);?> !important;">
	                <?php echo siteorigin_widget_get_icon($service['icon'], '');?>
	            </div>
	            <h3><?php echo wp_kses_post( $service['title'] ) ?></h3>
	    		<p><?php echo wp_kses_post( $service['subtitle'] ) ?></p>
	        </div><!-- end service_vertical_box -->
	    </div><!-- end owl -->
	<?php endforeach;?>
</div>