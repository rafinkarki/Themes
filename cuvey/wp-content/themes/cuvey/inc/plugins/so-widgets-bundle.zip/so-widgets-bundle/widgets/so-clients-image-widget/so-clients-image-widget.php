<?php
/*
Widget Name: Client's Logo widget
Description: A very simple widget to list client's logos.
Author: Sunil Chaulagain	
Author URI: http://tuchuk.com
*/

class SiteOrigin_Widget_ClientLogo_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-clientlogo',
			__('Client\'s Logo (Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A list of logos of client\'s.', 'siteorigin-widgets'),
				
			),
			array(

			),
			array(
				
	
				'image' => array(
					'type' => 'media',
					'label' => __('Image file', 'siteorigin-widgets'),
				),
				'url' => array(
					'type' => 'text',
					'label' => __('Destination Url', 'siteorigin-widgets'),
				),	
				'new_window' => array(
					'type' => 'checkbox',
					'label' => __('Open in new window?', 'siteorigin-widgets'),
				),		
				
				
			),
			plugin_dir_path(__FILE__).'../'
		);
	}

	

	function get_template_name($instance) {
		return 'base';
	}

	function get_style_name($instance) {
		return false;
	}

}

siteorigin_widget_register('clientlogo', __FILE__);