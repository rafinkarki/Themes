<?php
/*
Widget Name: Information widget
Description: Displays a carousel of text with heading and button.
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/
class SiteOrigin_Widget_Information_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-information',
			__( 'Information Carousel(Builder)', 'siteorigin-widgets' ),
			array(
				'description' => __('Displays a information text with heading in carousel', 'siteorigin-widgets' ),
				
			),
			array(),
			array(
				'informations' => array(
					'type' => 'repeater',
					'label' => __('Informations', 'siteorigin-widgets'),
					'item_name' => __('Information', 'siteorigin-widgets'),
					'item_label' => array(
						'selector' => "[id*='columns-icons-name']",
						'update_event' => 'change',
						'value_method' => 'val'
					),
					'fields' => array(					
				
						'title' => array(
							'type' => 'text',
							'label' => __('Name', 'siteorigin-widgets'),
							),
						'text' => array(
							'type' => 'textarea',
							'label' => __('Description', 'siteorigin-widgets'),
							),
						'btntext' => array(
							'type' => 'text',
							'label' => __('Button Text', 'siteorigin-widgets'),
							),
						'btnurl' => array(
							'type' => 'text',
							'label' => __('Button Url', 'siteorigin-widgets'),
							),				
				
						),
					),
				
				'new_window' => array(
					'type' => 'checkbox',
					'label' => __('Open In New Window', 'siteorigin-widgets'),
				),	
			)
		);	
	}

	

	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		return 'base';
	}

	
}
siteorigin_widget_register('information', __FILE__);