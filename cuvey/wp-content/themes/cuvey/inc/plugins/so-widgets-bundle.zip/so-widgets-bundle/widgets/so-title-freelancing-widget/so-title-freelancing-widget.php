<?php
/*
Widget Name: Freelancing Title widget
Description: Displays Title with subtitle
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/
class SiteOrigin_Widget_TitleFreelancing_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-titlefreelancing',
			__('Title-Freelancing(Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A simple title widget.', 'siteorigin-widgets'),
				
			),
			array(
				),
			array(
				'style' => array(
					'type' => 'checkbox',
					'label' => __('Background Colored Title', 'siteorigin-widgets'),
				),

				'title' => array(
					'type' => 'textarea',
					'label' => __('Title Text', 'siteorigin-widgets'),
					'description' => __( 'Use span tag with ratator class to rotate text eg. class="rotate" and text seperated by commas.', 'siteorigin-widgets' )
				),
				't_color' => array(
					'type' => 'color',
					'label' => __('Title Color', 'siteorigin-widgets'),
					'default'=>'#000',
				),
				'b_color' => array(
					'type' => 'color',
					'label' => __('Title Background  Color', 'siteorigin-widgets'),
					'default'=>'#282828',
				),
				'subtitle' => array(
					'type' => 'textarea',
					'label' => __('Sub Title Text', 'siteorigin-widgets'),
				),			

				'size' => array(
					'type' => 'select',
					'label' => __('Title Size', 'siteorigin-widgets'),
					'options' => array(
						'1' => __('H1', 'siteorigin-widgets'),
						'2' => __('H2', 'siteorigin-widgets'),
						'3' => __('H3', 'siteorigin-widgets'),
						'4' => __('H4', 'siteorigin-widgets'),
						'5' => __('H5', 'siteorigin-widgets'),
						'6' => __('H6', 'siteorigin-widgets'),
						
					)
				),

				'align' => array(
					'type' => 'select',
					'label' => __('Alignment', 'siteorigin-widgets'),
					'options' => array(
						'left' => __('Left', 'siteorigin-widgets'),
						'right' => __('Right', 'siteorigin-widgets'),
						'center' => __('Center', 'siteorigin-widgets'),
					)
				),
			)
		);
	}


	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		return 'base';
	}
}
siteorigin_widget_register('titlefreelancing', __FILE__);