<div class="color-purple boxed" style="background:<?php echo esc_html($instance['color']);?>;">
    <div class="widget">
    <?php if($instance['number']):?>
        <span class="icon-container border-radius wow <?php echo esc_attr($instance['animation']);?>"><?php echo esc_attr($instance['number']);?></span>
    <?php endif;?>
    <h3><?php echo esc_attr( $instance['title'] ); ?></h3>
    <p><?php echo nl2br(wp_kses_post( $instance['text'] )); ?></p>
    </div>
</div><!-- end col -->