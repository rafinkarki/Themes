<?php
/*
Widget Name: Team  widget
Description: Displays a team member with their designation and social media url.
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/
class SiteOrigin_Widget_Team_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-team',
			__( 'Team (Builder)', 'siteorigin-widgets' ),
			array(
				'description' => __('Displays a team members with their designation.', 'siteorigin-widgets' ),
				
			),
			array(),
			array(
				
				'number' => array(
					'type' => 'text',
					'label' => __('Number of team', 'siteorigin-widgets'),
					'defalut'=>'5'
					),

				'layout' => array(
					'type' => 'select',
					'label' => __('Team Layout Style', 'siteorigin-widgets'),
					'default' => 'atom',
					'options' => array(                              
                        'isotope'   =>'Catagory View', 
                        'alt-isotope'   =>'Alternate Catagory View',  
                        'alt-container'   =>'Conatiner View',                                                            
                        'container'   =>'Round Conatiner View',                         
                        '3-col'   =>'Container 3 Column', 
                        'simple'   =>'Team Image View', 
                        'carousel'   =>'Carousel View',                                
                              
					),
				),
				'new_window' => array(
					'type' => 'checkbox',
					'label' => __('Open In New Window', 'siteorigin-widgets'),
				),
				
			)
		);	
	}

	

	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		if($instance['layout']=='simple' || $instance['layout']=='carousel'):
			return 'simple';
		elseif($instance['layout']=='isotope' || $instance['layout']=='alt-isotope'):
			return 'isotope';
		else:
			return 'container';
		endif;
	}

	
}
siteorigin_widget_register('team', __FILE__);