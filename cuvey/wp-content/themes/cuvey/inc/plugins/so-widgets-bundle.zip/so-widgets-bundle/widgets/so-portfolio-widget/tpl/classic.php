<?php $col='';
$number=esc_attr($instance['number']);
if($instance['layout']=='2') $col='two'; if($instance['layout']=='3') $col='three'; if($instance['layout']=='4') $col='four';?>

<?php query_posts('post_type=portfolio&post_status=publish&posts_per_page='.$number.'&paged='. get_query_var('paged')); ?>
<div id="second" class="container bf">                
        <?php 
        $arguments = array(
        'type'                     => 'portfolio',
        'taxonomy'                 => 'portfolio_filter',
        'pad_counts'               => false 
        );         
        $categories = get_categories( $arguments );
        ?> 
        <?php if($instance['checkbox']==false):?>       
            <ul class="filter">        
                <li><a data-cat="all" href="#" class="active"><?php _e( 'All', 'creativ' ); ?></a></li>
                <?php foreach($categories as $category) { ?>
                <li><a data-cat="<?php echo $category->slug; ?>" href="#"><?php echo $category->name; ?></a></li>
                <?php } ?>
            </ul>
        <?php endif;?>
        
        <?php if (have_posts()) : ?>
            <ul id="<?php echo $col;?>-col-portfolio" class="items row-fluid">      
                <?php while (have_posts()) : the_post(); ?>
                <?php
                $portfolio_item_title = get_the_title( $post->ID );
                $image_url= wp_get_attachment_thumb_url( get_post_thumbnail_id($post->ID) );
                $thumb =  wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                 $terms = get_the_terms( $post->ID, 'portfolio_filter' );          
                if ( $terms && ! is_wp_error( $terms ) ) : 

                    $term_links = array();
                    foreach ( $terms as $term ) {
                        $term_links[] = $term->slug;
                    }
                                        
                    $filters = join( " ", $term_links );
                endif;   
                ?>
                <li class="<?php echo $filters; ?>">
                    <div class="bf-single-item wow fadeIn">
                        <?php $thumbnail = get_post_thumbnail_id($post->ID);                        
                           $img_url = wp_get_attachment_image_src( $thumbnail,'full'); //get img URL
                           $n_img = aq_resize( $img_url[0], $width = 263, $height = 198, $crop = true, $single = true, $upscale = true );
                        ?><img src="<?php echo esc_url($n_img);?>" alt=""> 
                        <div class="caption">
                            <div class="cap-in">                                    
                                <?php
                                    $filters = get_the_terms($post->ID,'portfolio_filter');
                                    $c_filter = '';
                                    if(!empty($filters)){
                                        foreach($filters as $f=>$filter){
                                            $c_filter .=  ($f==0) ? $filter->name : ', '.$filter->name;
                                        }
                                        echo "<p>".esc_html($c_filter)."</p>";
                                    }
                                ?>                                    
                                <h3><a href="<?php echo the_permalink();?>" title=""><?php creativ_post_title(); ?></a></h3>
                                <a href="<?php echo the_permalink();?>" title=""><span class="bubble border-radius"><i class="fa fa-link"></i></span></a>
                                <a href="<?php echo esc_url($img_url[0]);?>" rel="prettyPhoto" title=""><span class="bubble border-radius"><i class="fa fa-search"></i></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <?php endwhile; ?>              
            </ul>
        <?php else : ?>

            <?php get_template_part('partials/nothing-found'); ?>

        <?php endif; wp_reset_query();?>
        
    </div>  