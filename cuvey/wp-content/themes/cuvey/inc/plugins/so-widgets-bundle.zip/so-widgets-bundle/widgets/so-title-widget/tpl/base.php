
<div class="section-title text-<?php echo wp_kses_post( $instance['align'] ); ?>" >
<?php if(!empty( $instance['title'])):?>
    <h<?php  echo esc_attr($instance['size']);?> class="title-color" style="color:<?php echo esc_html($instance['color']);?>;">
         <?php echo wp_kses_post( $instance['title'] ); ?>
    </h<?php  echo $instance['size'];?>>

<?php endif;?>
<?php if(!empty($instance['line']))  : ?>
    <div class="divider"></div>
<?php endif; ?>
<?php if(!empty($instance['subtitle']))  : ?>
    <p><?php echo nl2br(wp_kses_post( $instance['subtitle'] )); ?></p>
<?php endif; ?>
</div>
