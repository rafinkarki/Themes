<?php
/*
Widget Name: Video widget
Description: Displays Video with title
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/
class SiteOrigin_Widget_Video_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-video',
			__('Video(Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A simple video widget.', 'siteorigin-widgets'),
				
			),
			array(
				),
			array(

				'video' => array(
					'type' => 'text',
					'label' => __('Video Url', 'siteorigin-widgets'),
					'description' => __( 'Give a video url.', 'siteorigin-widgets' )
				),
				
				'title' => array(
					'type' => 'text',
					'label' => __('Video Text', 'siteorigin-widgets'),
				),			

			)
		);
	}


	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		return 'base';
	}
}
siteorigin_widget_register('video', __FILE__);