<?php $number=esc_attr($instance['number']);?>
<?php query_posts('post_type=menu&post_status=publish&paged='. get_query_var('paged')); ?>              
    <?php 
        $arguments = array(
        'type'                     => 'menu',
        'taxonomy'                 => 'menu_meal',
        'pad_counts'               => false 
        );         
        $categories = get_categories( $arguments ); 
    ?>
    
    <div id="features" class="tabbable">
        <ul class="nav nav-tabs">
            <?php foreach($categories as $i=>$category) { ?>
                <li class="<?php if($i==0) echo 'active';?> dm-icon-effect-1"><a href="#<?php echo $category->slug; ?>" data-toggle="tab"><?php echo $category->name; ?></a></li>
            <?php } ?>
        </ul>        
        <?php if (have_posts()) : $count=0;?>
        <div class="tab-content row">
            <?php foreach($categories as $i=>$category) { ?>
                <div class="tab-pane <?php if($i==0) echo 'active';?>" id="<?php echo $category->slug;?>">
                 <?php 
                    $arguments = array(
                      'post_type' => 'menu',
                      'post_status' => 'publish',
                      'posts_per_page'=>$number,
                      'tax_query' => array(
                          array(
                            'taxonomy' => 'menu_meal',
                            'field' => 'id',
                            'terms' => $category->cat_ID,
                          )
                      ),
                      // 'post__not_in' => array (get_the_ID()),
                      );
                      $menu_items = new WP_Query( $arguments ); 
                if($menu_items->have_posts()):?> 
                 <?php while ($menu_items->have_posts()) : $menu_items->the_post(); ?>                   
                    <div class="<?php if($count%2==0): echo $left; else: echo $right; endif;?> col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="menu-res">
                            <div class="item clearfix">
                                <div class="ImageWrapper pull-left border-radius red-effect">
                                    <?php $thumbnail = get_post_thumbnail_id($post->ID);                        
                                       $img_url = wp_get_attachment_image_src( $thumbnail,'full'); //get img URL
                                       //$n_img = aq_resize( $img_url[0], $width = 263, $height = 198, $crop = true, $single = true, $upscale = true );
                                    ?>
                                    <img class="img-responsive img-circle" src="<?php echo esc_url($img_url[0]);?>" alt="">
                                    <div class="ImageOverlayLi"></div>
                                    <!-- <div class="Buttons StyleH">
                                        <span><a href="shop.html">Order Now</a></span>
                                    </div> -->
                                </div>

                                <div class="res-title">
                                    <h3><?php creativ_post_title(); ?></h3>
                                </div><!-- end title -->                     

                                <div class="desc">
                                    <p>
                                        <?php 
                                            //$postContentStr = apply_filters('the_content', strip_shortcodes($post->post_content));
                                            echo wp_kses_post(the_content());  
                                        ?>
                                    </p>
                                </div><!-- end desc -->
                                <?php $price =esc_attr(get_post_meta(get_the_ID(), 'creativ_price', true ));?>
                                <?php if(!empty($price)):?>
                                    <div class="price">
                                        <div class="pull-left">
                                            <h4><?php echo $price;?></h4>
                                        </div><!-- end left -->
                                    </div><!-- end price -->
                                <?php endif;?>
                            </div><!-- end item -->
                        </div>
                    </div>   
                    <?php ++$count;?> 
               <?php endwhile;?>
           <?php endif; wp_reset_postdata();?>
               </div><!-- end tabpane -->
            <?php }?>
        </div>
        <?php else : ?>
            <?php get_template_part('partials/nothing-found'); ?>
        <?php endif; wp_reset_query();?>
    </div>   
  