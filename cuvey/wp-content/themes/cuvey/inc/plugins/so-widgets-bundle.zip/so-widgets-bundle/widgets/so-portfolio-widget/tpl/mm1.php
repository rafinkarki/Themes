<?php $number=esc_attr($instance['number']);?>
<?php query_posts('post_type=portfolio&post_status=publish&posts_per_page='.$number.'&paged='. get_query_var('paged')); ?>
      
    
<?php if (have_posts()) : ?>
<div class="clearfix">
    <div class="container-full">
        <div class="mixed-container masonry_wrapper row">
            <?php while (have_posts()) : the_post(); ?>
            <?php
            $portfolio_item_title = get_the_title( $post->ID );
            $image_url= wp_get_attachment_thumb_url( get_post_thumbnail_id($post->ID) );
            $thumb =  wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
             $terms = get_the_terms( $post->ID, 'portfolio_filter' );          
            if ( $terms && ! is_wp_error( $terms ) ) : 

                $term_links = array();
                foreach ( $terms as $term ) {
                    $term_links[] = $term->slug;
                }
                                    
                $filters = join( " ", $term_links );
            endif;   
            ?>
            <div class="item wow fadeIn">
            <a href="<?php the_permalink();?>">
                <figure class="effect-chico">
                    <?php $thumbnail = get_post_thumbnail_id($post->ID);                        
                       $img_url = wp_get_attachment_image_src( $thumbnail,'full'); //get img URL
                    ?><img src="<?php echo esc_url($img_url[0]);?>" alt="" class="img-responsive"> 
                    <figcaption>
                        <h3><i class="fa fa-link"></i></h3>                                                                    
                        <?php
                            $filters = get_the_terms($post->ID,'portfolio_filter');
                            $c_filter = '';
                            if(!empty($filters)){
                                foreach($filters as $f=>$filter){
                                    $c_filter .=  ($f==0) ? $filter->name : ', '.$filter->name;
                                }
                                echo "<p>".esc_html($c_filter)."</p>";
                            }
                        ?> 
                    </figcaption>
                </figure>
            </a>
            </div>
            <?php endwhile; ?>              
        </div>
    </div>
</div>
<?php else : ?>

    <?php get_template_part('partials/nothing-found'); ?>

<?php endif; wp_reset_query();?>