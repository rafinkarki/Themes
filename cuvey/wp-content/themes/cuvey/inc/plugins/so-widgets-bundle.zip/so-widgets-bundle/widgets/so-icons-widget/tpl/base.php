<div class="fullboxed-wrap section-content  clearfix">
    <div class="widget">
    	<?php foreach($instance['icons'] as $i => $icon) : ?>                          
               
	        <div class="col-md-6 col-sm-6 col-xs-12 box-wrap color-blue" style="background:<?php echo esc_attr($icon['bg_color']);?>;">
	            <div class="front">
	        		<?php echo siteorigin_widget_get_icon($icon['icon'], '');?>
	            </div>
	            <div class="back">
	            	<?php echo siteorigin_widget_get_icon($icon['icon'], '');?>
	                <h3><?php echo esc_attr( $icon['title'] ) ?></h3>
	            </div><!-- end back -->
	        </div><!-- end col -->

        <?php endforeach;?>  
    </div><!-- end widget -->
</div><!-- end col -->