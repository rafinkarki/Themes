<?php $src = wp_get_attachment_image_src($instance['image'],$instance['size']); ?>
<div class="photo-gallery wow <?php echo esc_attr($instance['animation']);?>">
    <img src="<?php echo esc_url($src[0]);?>" alt="" class="img-responsive">
    <div class="gallery-desc <?php if($instance['meta']['align']=='left'): echo 'right-slot'; endif;?>">
    	<?php if(!empty($instance['meta']['title'])):?>
	        <h3>
			<?php if( !empty( $instance['meta']['url'] ) )
		        echo '<a  href="' . esc_url( $instance['meta']['url'] ) . '" ' . ( $instance['meta']['new_window'] ? 'target="_blank"' : '' ) . ' title="">'; ?>
		        <?php echo esc_attr($instance['meta']['title']);?>
	        <?php if( !empty( $instance['meta']['url'] ) ) echo'</a>';?>
	        </h3>
	    <?php endif;?>
	    <?php if(!empty($instance['meta']['name'])):?>
        	<p><?php _e('by ','siteorigin-widgets');?><?php echo esc_attr($instance['meta']['name']);?></p>
        <?php endif;?>
    </div>
</div>