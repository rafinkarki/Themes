<?php
/*
Widget Name: Restaurant Menu widget
Description: A simple menu list for different meals with price and images.
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/

class SiteOrigin_Widget_RestaurantMenu_Widget extends SiteOrigin_Widget {
	function __construct() {

		parent::__construct(
			'sow-restaurantmenu',
			__('Restaurant Menu(Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A simple restaurant menu widget for different meals.', 'siteorigin-widgets'),
			),
			array(

			),
			array(
				'number' => array(
					'type' => 'text',
					'label' => __('Number of menu items per meals', 'siteorigin-widgets'),
					'default'=>'3',
				),	
				'type' => array(
					'type' => 'select',
					'label' => __('Menu Display Type', 'siteorigin-widgets'),
					'options' => array(
						'tab' => __('Menu Tab', 'siteorigin-widgets'),
						'featured' => __('Featured Menu Items', 'siteorigin-widgets'),
					),
				),			
			),			
		
			plugin_dir_path(__FILE__)
		);

	}
	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance) {
		return $instance['type'];
	}

}

siteorigin_widget_register('restaurantmenu', __FILE__);