<div class="shortcode-widget section-content">
    <div id="aboutslider" class="flexslider flex-direction-nav-on-top">
        <ul class="slides">
        <?php foreach($instance['images'] as $image):?>
        	<?php $src = wp_get_attachment_image_src($image['image'],'full');  ?>
            <li><img src="<?php echo esc_url($src[0]);?>" class="img-responsive" alt="<?php echo esc_attr($image['alt']);?>"></li>
        <?php endforeach;?>
        </ul><!-- end slides -->
        <div class="aboutslider-shadow">
            <span class="s1"></span>
        </div>
    </div><!-- end slider -->
</div><!-- end col -->

