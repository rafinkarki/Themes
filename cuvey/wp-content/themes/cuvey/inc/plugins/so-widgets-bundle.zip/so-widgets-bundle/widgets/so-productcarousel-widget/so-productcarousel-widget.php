<?php
/*
Widget Name: Products  widget
Description: Gives you a widget to display your product as a carousel.
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/



class SiteOrigin_Widget_Productcarousel_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-productcarousel',
			__(' Product(Builder) ', 'siteorigin-widgets'),
			array(
				'description' => __('Display a carousel of latest products.', 'siteorigin-widgets'),
				'help' => 'http://tuchuk.com/support/'
			),
			array(

			),
			array(
				// 'product-type' => array(
				// 		'type' => 'select',
				// 		'label' => __('Product Type', 'siteorigin-widgets'),
				// 		'options' => array(
				// 			'featured' => __('Featured', 'siteorigin-widgets'),
				// 			'top' => __('Top Rated', 'siteorigin-widgets'),						
											
				// 		)
				// 	),
				
				'num' => array(
					'type' => 'number',
					'label' => __('Product number', 'siteorigin-widgets'),
					'default' => '10',
				),


			),
			plugin_dir_path(__FILE__).'../'
		);
	}

	function get_template_name($instance){
		return 'base';
	}

	function get_style_name($instance){
		return false;
	}
}

siteorigin_widget_register('productcarousel', __FILE__);