<?php
/*
Widget Name: Shop Title widget
Description: Displays Title for product page
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/
class SiteOrigin_Widget_ShopTitle_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-shoptitle',
			__('Shop Title(Builder)', 'siteorigin-widgets'),
			array(
				'description' => __('A simple title widget for product page.', 'siteorigin-widgets'),
				
			),
			array(
				),
			array(

				'title' => array(
					'type' => 'text',
					'label' => __('Title Text', 'siteorigin-widgets'),
					
				),
							

				'size' => array(
					'type' => 'select',
					'label' => __('Title Size', 'siteorigin-widgets'),
					'options' => array(
						'1' => __('H1', 'siteorigin-widgets'),
						'2' => __('H2', 'siteorigin-widgets'),
						'3' => __('H3', 'siteorigin-widgets'),
						'4' => __('H4', 'siteorigin-widgets'),
						'5' => __('H5', 'siteorigin-widgets'),
						'6' => __('H6', 'siteorigin-widgets'),
						
					)
				),

			)
		);
	}


	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		return 'base';
	}
}
siteorigin_widget_register('shoptitle', __FILE__);