<?php $number=esc_attr($instance['number']);?>
<?php query_posts('post_type=team&post_status=publish&posts_per_page='.$number.'&paged='. get_query_var('paged')); ?>
<?php if($instance['layout']=='alt-container'):   
    $div='<div class="ImageWrapper">';
    $flag=0;
    $class='col-md-3 col-sm-3 col-xs-12';
elseif($instance['layout']=='3-col'):
    $div='<div class="ImageWrapper">';
    $flag=0;  
    $class='col-md-4 col-sm-4 col-xs-12';
else:
    $div='<div class="ImageWrapper border-radius dark-effect">';
    $flag=1;
    $class='col-md-3 col-sm-3 col-xs-12';
endif;?>
        <?php if (have_posts()) :  ?>
        <div class="team-list">            
            <?php while (have_posts()) : the_post();?>
              <?php  $pageid=get_the_ID();  
                $facebook=esc_attr(get_post_meta( $pageid, 'creativ_facebook',true));
                $twitter=esc_attr(get_post_meta( $pageid, 'creativ_twitter',true));
                $google=esc_attr(get_post_meta( $pageid, 'creativ_google',true));?>
                
                <div class="<?php echo $class;?> wow fadeIn">
                    <div class="owl-team">
                        <div class="team-member wow fadeIn">
                            <?php echo $div;?>
                                <?php $thumbnail = get_post_thumbnail_id($post->ID);                        
                                   $img_url = wp_get_attachment_image_src( $thumbnail,'full'); //get img URL
                                   $n_img = aq_resize( $img_url[0], $width = 285, $height = 300, $crop = true, $single = true, $upscale = true ); 
                                ?><img src="<?php echo esc_url($img_url[0]);?>" <?php if($flag==1) echo'class="img-circle"';?> alt=""> 
                                <div class="ImageOverlayLi"></div>
                                <div class="Buttons StyleH">
                                    <div class="social-icons">
                                        <?php if (!empty($twitter)) : ?>
                                            <span><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom"  data-title="Twitter"  href="<?php echo esc_url( $twitter);?>" <?php echo  $instance['new_window'] ? 'target="_blank"' : '';  ?> ><i class="fa fa-twitter"></i></a></span>
                                        <?php endif;?>                       
                                        <?php if (!empty($facebook)) : ?>
                                            <span><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom"  data-title="Facebook" href="<?php echo esc_url( $facebook );?>" <?php echo  $instance['new_window'] ? 'target="_blank"' : '';  ?> ><i class="fa fa-facebook"></i></a></span>
                                        <?php endif;?>
                                        <?php if (!empty($google)) : ?>
                                            <span><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom"  data-title="Google Plus" href="<?php echo esc_url( $google );?>" <?php echo  $instance['new_window'] ? 'target="_blank"' : '';  ?>> <i class="fa fa-google-plus"></i></a></span>
                                        <?php endif;?>
                                    </div><!-- end social icons -->
                                </div>
                            </div>
                            <div class="team_desc">
                                <h3><?php creativ_post_title(); ?></h3>
                                <?php
                                $filters = get_the_terms($post->ID,'team_post');
                                $c_filter = '';
                                if(!empty($filters)){
                                    foreach($filters as $f=>$filter){
                                        $c_filter .=  ($f==0) ? $filter->name : ', '.$filter->name;
                                    }
                                    echo "<p>".esc_html($c_filter)."</p>";
                                }
                                ?>  
                            </div><!-- end team_Desc -->
                        </div><!-- end ImageWrapper -->
                    </div>       
                </div><!-- end col -->
              
            <?php endwhile; ?>              
        </div>   
            <?php else : ?>

                <?php get_template_part('partials/nothing-found'); ?>

        <?php endif; wp_reset_query();?>
   