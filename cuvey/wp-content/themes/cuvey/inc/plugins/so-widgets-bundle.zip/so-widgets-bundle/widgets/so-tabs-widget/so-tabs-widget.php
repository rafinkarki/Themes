<?php
/*
Widget Name: Tabs Widget
Description: Displays a block of tabs with icons .
Version: trunk
Author: Sunil chaulagain
Author URI: http://tuchuk.com
*/

class SiteOrigin_Widget_Tabs_Widget extends SiteOrigin_Widget {
	function __construct() {
		parent::__construct(
			'sow-tabs',
			__( 'Tabs (Builder)', 'siteorigin-widgets' ),
			array(
				'description' => __( 'Displays a group of tabs with image and icons.', 'siteorigin-widgets' ),
			),
			array(),
			array(
				'tabs' => array(
					'type' => 'repeater',
					'label' => __('Tabs', 'siteorigin-widgets'),
					'item_name' => __('Tab', 'siteorigin-widgets'),
					'item_label' => array(
						'selector' => "[id*='tabs-title']",
						'update_event' => 'change',
						'value_method' => 'val'
					),
					'fields' => array(
					
						'icon' => array(
							'type' => 'icon',
							'label' => __('Tab Icon', 'siteorigin-widgets'),
						),
						'color' => array(
							'type' => 'color',
							'label' => __('Tab Color', 'siteorigin-widgets'),
							
						),
						'title' => array(
							'type' => 'text',
							'label' => __('Body Title', 'siteorigin-widgets'),
						),
						'text' => array(
							'type' => 'textarea',
							'label' => __('Description', 'siteorigin-widgets'),
						),
						'image' => array(
							'type' => 'media',
							'label' => __('Image File', 'siteorigin-widgets'),
						),						
						
						'active' => array(
							'type' => 'checkbox',
							'label' => __('Is this active tab ? ', 'siteorigin-widgets'),
							'default' => false,
						),
						
					),
				),
							

			),
			plugin_dir_path(__FILE__).'../'
		);
	}

	function get_style_name($instance){
		return false;
	}

	function get_template_name($instance){
		return 'base';
	}

}
siteorigin_widget_register('tabs', __FILE__);