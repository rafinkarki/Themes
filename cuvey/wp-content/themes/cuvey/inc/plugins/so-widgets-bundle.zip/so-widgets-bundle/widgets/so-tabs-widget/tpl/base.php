<div id="colorful-tab" role="tabpanel">
      <!-- Nav tabs -->
    <ul class="nav nav-tabs" role="tablist">
         <?php foreach( $instance['tabs'] as $i => $tab ) : ?>
            <li role="presentation" class="<?php if( $tab['active'] ) echo 'active'; ?> color<?php echo $i;?> border-radius" style="background:<?php echo $tab['color']; ?>;" >
                <a href="#<?php echo $i;?>" aria-controls="<?php echo $i;?>" role="tab" data-toggle="tab">
                <?php $icon_styles = array();
                $icon_styles[] = 'font-size: 25px';
                echo siteorigin_widget_get_icon($tab['icon'], $icon_styles);?>
                </a>
            </li>       
         <?php endforeach; ?>
    </ul>

    <div class="tab-content">
        <?php foreach( $instance['tabs'] as $i => $tab ) : ?>
            <div role="tabpanel" class="tab-pane fade in <?php if( $tab['active'] ) echo 'active'; ?> color<?php echo $i;?>" style="background:<?php echo $tab['color']; ?>;" id="<?php echo $i;?>">
                <div class="service_vertical_box">
                    <?php  $src = wp_get_attachment_image_src($tab['image'],'full');
                    if($src[0]):?>
                        <div class="service-icon">
                            <img src="<?php echo esc_url($src[0]);?>" alt="" class="img-circle">
                        </div>
                    <?php endif;?>
                    <h3><?php echo esc_attr( $tab['title'] ) ?></h3>
                        <p><?php echo wp_kses_post( $tab['text'] ) ?></p>
                </div><!-- end service_vertical_box -->
            </div>
        <?php endforeach;?>
    </div>
</div>