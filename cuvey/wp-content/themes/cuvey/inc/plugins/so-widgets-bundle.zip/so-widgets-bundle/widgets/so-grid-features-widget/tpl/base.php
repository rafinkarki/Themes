<?php foreach($instance['features'] as $i => $feature) : ?>
	<?php if($instance['style']=='grid'):?>
		<div class="col-md-4 col-sm-4 col-xs-12 border-boxed wow <?php echo esc_attr($instance['icon_animation']);?>">
		    <div class="service-hover">
		        <div class="front">
		            <?php echo siteorigin_widget_get_icon($feature['icon'], '');?>
		            <h3><?php echo wp_kses_post( $feature['title'] ) ?></h3>
		        </div><!-- end front -->
		        <div class="back">
		            <?php echo siteorigin_widget_get_icon($feature['icon'], '');?>
		            <h3><?php echo wp_kses_post( $feature['title'] ) ?></h3>
		            <p><?php echo wp_kses_post( $feature['description'] ) ?></p>
		            <?php if( $feature['btnurl']!='') : ?>
			        	<a href="<?php echo esc_url( $feature['btnurl'] ); ?>" <?php echo $instance['new_window'] ? 'target="_blank"' : '' ; ?> class="btn btn-primary border-radius"><?php echo wp_kses_post( $feature['btntext'] ); ?></a>
			        <?php endif; ?>
		        </div><!-- end back -->
		    </div><!-- end service-hover -->
		</div>
	<?php else:?>
		<div class="col-md-4 col-sm-4 col-xs-12">
            <div class="full-height color-blue wow <?php echo esc_attr($instance['icon_animation']);?>" style="background:<?php echo $feature['color'];?>;">
            <div class="service-hover">
		        <div class="front">
		            <?php echo siteorigin_widget_get_icon($feature['icon'], '');?>
		            <h3><?php echo wp_kses_post( $feature['title'] ) ?></h3>
		        </div><!-- end front -->
		        <div class="back">
		            <?php echo siteorigin_widget_get_icon($feature['icon'], '');?>
		            <h3><?php echo wp_kses_post( $feature['title'] ) ?></h3>
		            <p><?php echo wp_kses_post( $feature['description'] ) ?></p>
		            <?php if( $feature['btnurl']!='') : ?>
			        	<a href="<?php echo esc_url( $feature['btnurl'] ); ?>" <?php echo $instance['new_window'] ? 'target="_blank"' : '' ; ?> class="btn btn-primary border-radius"><?php echo wp_kses_post( $feature['btntext'] ); ?></a>
			        <?php endif; ?>
		        </div><!-- end back -->
		    </div><!-- end service-hover -->
            </div>
        </div>
	<?php endif;?>
<?php endforeach;?>